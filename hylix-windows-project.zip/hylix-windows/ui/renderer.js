"use strict";
const desktop = window.hylixDesktop;
const address = document.getElementById("address");
const status = document.getElementById("status");
const submit = document.querySelector(".primary");
function result(value) {
  if (value && !value.ok) status.textContent = value.message;
}
desktop?.onStatus((value) => {
  status.textContent = value.message;
  submit.disabled = value.busy;
  document.body.classList.toggle("starting", value.busy);
});
desktop
  ?.settings()
  .then((value) => {
    if (value.ok) {
      address.value = value.address;
      if (value.online) {
        address.readOnly = true;
        document.querySelector('label[for="address"]').hidden = true;
        address.hidden = true;
        document.getElementById('project').hidden = true;
        document.querySelector('summary').textContent = 'More options';
      }
    }
    else result(value);
  })
  .catch(() => {
    status.textContent = "Restart Hylix to reconnect.";
  });
document
  .getElementById("connection")
  .addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!desktop) return;
    try {
      result(await desktop.connect(address.value));
    } catch {
      status.textContent = "The connection could not complete. Try again.";
    }
  });
document.getElementById("project").addEventListener("click", async () => {
  if (!desktop) return;
  try {
    const value = await desktop.chooseProject();
    result(value);
    if (value.projectSelected)
      status.textContent = "Project selected. Choose Open Hylix to continue.";
  } catch {
    status.textContent = "The project could not be selected.";
  }
});
document.getElementById("browser").addEventListener("click", async () => {
  if (!desktop) return;
  try {
    result(await desktop.openBrowser());
  } catch {
    status.textContent = "Your browser could not open.";
  }
});
