"use strict";
const LOOPBACK = new Set(["127.0.0.1", "localhost", "[::1]"]);
function siteAddress(value) {
  if (typeof value !== "string" || value.length > 2000)
    throw new Error("Enter a Hylix website address.");
  let url;
  try {
    url = new URL(value.trim());
  } catch {
    throw new Error("Enter a full website address, including https://.");
  }
  if (
    url.username ||
    url.password ||
    url.search ||
    url.hash ||
    !["", "/"].includes(url.pathname)
  )
    throw new Error(
      "Use the main website address without a password, query, or page path.",
    );
  if (
    url.protocol !== "https:" &&
    !(url.protocol === "http:" && LOOPBACK.has(url.hostname))
  )
    throw new Error(
      "Use HTTPS, or a local address such as http://127.0.0.1:3000.",
    );
  return url.origin + "/";
}
function sameSite(value, site) {
  try {
    return new URL(value).origin === new URL(siteAddress(site)).origin;
  } catch {
    return false;
  }
}
function externalAddress(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password;
  } catch {
    return false;
  }
}
function localDevelopment(value) {
  const url = new URL(siteAddress(value));
  return (
    url.protocol === "http:" &&
    LOOPBACK.has(url.hostname) &&
    url.port === "3000"
  );
}
module.exports = { siteAddress, sameSite, externalAddress, localDevelopment };
