'use strict';
const fs=require('node:fs/promises'); const path=require('node:path'); const {DatabaseSync,backup}=require('node:sqlite'); const {parseEnv}=require('node:util');
async function initializeData(runtime,data){
 await fs.mkdir(data, {recursive:true});
 const envPath = path.join(data,'.env');
 const dbPath = path.join(data,'hylix.db');
 let ready = false;
 try { await fs.access(path.join(data,'.initialized')); ready = true; } catch {}
 if (!ready) {
   let source;
   try { const config=JSON.parse(await fs.readFile(path.join(path.dirname(data),'import-source.json'),'utf8')); if (typeof config.project==='string') source=config.project; } catch {}
   let values = { ASSET_HOSTS:'image.tmdb.org', STREAM_HOSTS:'' };
   if (source) {
     const metadata=JSON.parse(await fs.readFile(path.join(source,'package.json'),'utf8'));
     if (metadata.name!=='hylix') throw Error('Invalid Hylix import');
     const imported=parseEnv(await fs.readFile(path.join(source,'.env'),'utf8'));
     const allowed=['ASSET_HOSTS','STREAM_HOSTS','TMDB_READ_TOKEN','GOOGLE_CLIENT_ID','GOOGLE_CLIENT_SECRET','APPLE_CLIENT_ID','APPLE_TEAM_ID','APPLE_KEY_ID','APPLE_PRIVATE_KEY','BENTIO_URL','BENTIO_TOKEN'];
     for (const key of allowed) if (imported[key]) values[key]=imported[key];
     if (!imported.DATABASE_URL?.startsWith('file:')) throw Error('Invalid local database');
     const original=path.resolve(source,'prisma',imported.DATABASE_URL.slice(5));
     const database=new DatabaseSync(original,{readOnly:true});
     try { await backup(database,dbPath); } finally { database.close(); }
     await fs.cp(path.join(source,'public'),path.join(data,'public'),{recursive:true});
   } else {
     await fs.copyFile(path.join(runtime,'catalog.db'),dbPath);
     await fs.mkdir(path.join(data,'public','art'),{recursive:true});
   }
   values.DATABASE_URL='file:'+dbPath.replaceAll('\\','/');
   values.APP_ORIGIN='http://127.0.0.1:3000';
   await fs.writeFile(envPath,Object.entries(values).map(([key,value])=>key+'='+JSON.stringify(value)).join('\n')+'\n',{mode:0o600});
   await fs.writeFile(path.join(data,'.initialized'),'1');
 }

return {envPath,dbPath};
}
module.exports={initializeData};
