"use strict";
const fs = require('node:fs/promises');
const path = require('node:path');
const { parseEnv } = require('node:util');
async function main() {
 const [runtime, data, port = '3000'] = process.argv.slice(2);
 if (!path.isAbsolute(runtime || '') || !path.isAbsolute(data || '')) throw Error('Invalid runtime');
 if (!/^\d{4,5}$/.test(port) || Number(port) < 1024 || Number(port) > 65535) throw Error('Invalid runtime port');
 const {envPath,dbPath}=await require('./data.cjs').initializeData(runtime,data);
 const values=parseEnv(await fs.readFile(envPath,'utf8'));
 Object.assign(process.env,values,{
   NODE_ENV:'production', DATABASE_URL:'file:'+dbPath.replaceAll('\\','/'),
   APP_ORIGIN:'http://127.0.0.1:'+port, HOSTNAME:'127.0.0.1', PORT:port,
   HYLIX_ENV_PATH:envPath, HYLIX_PUBLIC_DIR:path.join(data,'public'),
   NEXT_TELEMETRY_DISABLED:'1', HYLIX_DESKTOP_RUNTIME:'1'
 });
 process.chdir(runtime);
 require(path.join(runtime,'server.js'));
}
main().catch((error)=>{ if(process.env.HYLIX_DIAGNOSTICS==='1') console.error(error.name, error.code, error.code==='MODULE_NOT_FOUND' ? String(error.message).split('\n')[0] : '', String(error.stack).split('\n').filter(line=>line.trim().startsWith('at ')).join('\n'));  process.stderr.write('Hylix local startup failed. Your existing data has not been removed.\n'); process.exit(1); });
