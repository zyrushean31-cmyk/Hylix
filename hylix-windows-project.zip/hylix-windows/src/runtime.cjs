"use strict";
const fs = require('node:fs/promises');
const path = require('node:path');
// Program files are already installed. Only the catalog, uploads and private
// configuration belong in userData; copying the runtime delays every upgrade.
async function installedRuntime(resources) {
  const runtime = path.resolve(resources, 'server');
  const required = [
    'server.js', 'catalog.db', '.next-desktop/BUILD_ID',
    '.next-desktop/server/preview-props.json', '.next-desktop/static',
    'node_modules/next/package.json', 'node_modules/.prisma/client/default.js',
  ];
  await Promise.all(required.map(file => fs.access(path.join(runtime, file))));
  return runtime;
}
module.exports = { installedRuntime };
