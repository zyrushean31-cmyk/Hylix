'use strict';
const { siteAddress } = require('./policy.cjs');
const net = require('node:net');

function desktopConfiguration(value) {
  if (value === undefined) return { mode: 'local', origin: 'http://127.0.0.1:3000/' };
  if (!value || value.mode !== 'online') throw Error('Invalid Hylix distribution configuration');
  const origin = siteAddress(value.origin);
  const url = new URL(origin);
  if (url.protocol !== 'https:' || net.isIP(url.hostname.replace(/^\[|\]$/g, '')) ||
      !url.hostname.includes('.') || /(?:^|\.)(?:localhost|local|test|invalid|example)$/.test(url.hostname) ||
      /(?:^|\.)example\.(?:com|org|net)$/.test(url.hostname)) {
    throw Error('Public builds require the real HTTPS Hylix service address');
  }
  const repository = value.repository;
  if (typeof repository !== 'string' || !/^[A-Za-z0-9_-]+\/[A-Za-z0-9_.-]+$/.test(repository))
    throw Error('Set the GitHub owner/repository for Hylix releases');
  return { mode: 'online', origin, repository, releases: `https://github.com/${repository}/releases/latest` };
}
module.exports = { desktopConfiguration };
