'use strict';

function updateController(updater, prompt) {
  updater.autoDownload = false;
  updater.autoInstallOnAppQuit = false;
  updater.allowDowngrade = false;
  updater.allowPrerelease = false;
  // The checked promise handles failures. Do not log server responses or tokens.
  updater.on('error', () => {});
  let busy = false;
  return async function check() {
    if (busy) return;
    busy = true;
    let available;
    const onAvailable = info => { available = info; };
    updater.on('update-available', onAvailable);
    try {
      await updater.checkForUpdates();
      updater.removeListener('update-available', onAvailable);
      if (!available) {
        await prompt({ type:'info', title:'Hylix', message:'Hylix is up to date.', buttons:['OK'] });
        return;
      }
      const choice=await prompt({ type:'info', title:'Hylix update',
        message:'A new version of Hylix is available.',
        detail:'Download it now? Your library stays with your Hylix account.',
        buttons:['Download update','Later'], defaultId:0, cancelId:1 });
      if (choice.response !== 0) return;
      await updater.downloadUpdate();
      const restart=await prompt({ type:'info', title:'Hylix update',
        message:'Your update is ready.', detail:'Restart Hylix to finish installing it.',
        buttons:['Restart now','Later'], defaultId:0, cancelId:1 });
      if (restart.response === 0) updater.quitAndInstall(false, true);
    } catch {
      await prompt({ type:'info', title:'Hylix update',
        message:'Updates could not be checked or downloaded.',
        detail:'Your current Hylix app is still available. Try again later.', buttons:['OK'] });
    } finally {
      updater.removeListener('update-available', onAvailable);
      busy=false;
    }
  };
}
module.exports = { updateController };
