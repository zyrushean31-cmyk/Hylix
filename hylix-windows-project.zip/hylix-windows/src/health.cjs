'use strict';

async function localHealth(address, fetcher = fetch) {
  try {
    const response = await fetcher(new URL('/api/health', address), {
      signal: AbortSignal.timeout(1500), redirect: 'error', cache: 'no-store',
    });
    if (!response.ok || !response.headers.get('content-type')?.includes('application/json')) return false;
    const status = await response.json();
    return status.service === 'hylix' && status.ready === true && status.protocol === 1;
  } catch { return false; }
}
module.exports = { localHealth };
