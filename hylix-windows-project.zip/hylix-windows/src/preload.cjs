"use strict";
const { contextBridge, ipcRenderer } = require("electron");
if (window.location.protocol === "file:") {
  contextBridge.exposeInMainWorld("hylixDesktop", {
    settings: () => ipcRenderer.invoke("hylix:settings"),
    connect: (address) => ipcRenderer.invoke("hylix:connect", address),
    chooseProject: () => ipcRenderer.invoke("hylix:choose-project"),
    openBrowser: () => ipcRenderer.invoke("hylix:browser"),
    onStatus: (callback) => {
      const listener = (_event, value) => callback(value);
      ipcRenderer.on("hylix:status", listener);
      return () => ipcRenderer.removeListener("hylix:status", listener);
    },
  });
}
