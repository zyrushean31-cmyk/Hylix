"use strict";
const {
  app,
  BrowserWindow,
  Menu,
  ipcMain,
  dialog,
  shell,
  session,
  Tray,
} = require("electron");
const { showReadyWindow, keepReadyOnClose } = require('./quick-reopen.cjs');
const { installedRuntime } = require("./runtime.cjs");
const { localHealth } = require("./health.cjs");
const { desktopConfiguration } = require("./distribution.cjs");
const distribution = desktopConfiguration(require('../package.json').hylix);
const online = distribution.mode === 'online';
const { spawn } = require("node:child_process");
const fs = require("node:fs/promises");
const path = require("node:path");
const { pathToFileURL } = require("node:url");
const {
  siteAddress,
  sameSite,
  externalAddress,
  localDevelopment,
} = require("./policy.cjs");
let launcher,
  cinema,
  tray,
  ownedServer,
  cinemaLoaded = false,
  connecting = false,
  closing = false;
let lastMessage = "Opening your cinema…";
let settings = { address: distribution.origin, project: "" };
let checkUpdates;
async function updates() {
  if (!online || !app.isPackaged) return;
  if (!checkUpdates) {
    const { autoUpdater } = require('electron-updater');
    const { updateController } = require('./updates.cjs');
    checkUpdates = updateController(autoUpdater, options => {
      const parent = cinema && !cinema.isDestroyed() ? cinema : launcher;
      return parent && !parent.isDestroyed()
        ? dialog.showMessageBox(parent, options) : dialog.showMessageBox(options);
    });
  }
  await checkUpdates();
}
const uiFile = path.join(__dirname, "../ui/index.html");
const uiUrl = pathToFileURL(uiFile).href;
const icon = path.join(__dirname, "../assets/icon.png");
const settingsFile = () =>
  path.join(app.getPath("userData"), "connection.json");
async function saveSettings() {
  await fs.mkdir(app.getPath("userData"), { recursive: true });
  await fs.writeFile(settingsFile(), JSON.stringify(settings, null, 2), "utf8");
}
function status(message, busy = false) {
  lastMessage = message;
  if (launcher && !launcher.isDestroyed())
    launcher.webContents.send("hylix:status", { message, busy });
}
function showLauncher(message) {
  if (launcher && !launcher.isDestroyed()) {
    launcher.show();
    launcher.focus();
  }
  if (message) status(message);
}
async function projectAvailable(project) {
  try {
    const metadata = JSON.parse(
      await fs.readFile(path.join(project, "package.json"), "utf8"),
    );
    await fs.access(path.join(project, "node_modules/next/dist/bin/next"));
    await fs.access(path.join(project, ".env"));
    return metadata.name === "hylix";
  } catch {
    return false;
  }
}
async function startLocalServer() {
  if (!localDevelopment(settings.address)) return false;
  if (ownedServer && ownedServer.exitCode === null) return true;
  const resources = app.isPackaged ? process.resourcesPath : path.join(__dirname, '../bundle');
  status('Preparing your cinema…', true);
  const runtime = await installedRuntime(resources);
  const data = path.join(app.getPath('userData'), 'data');
  const importFile = path.join(app.getPath('userData'), 'import-source.json');
  if (settings.project && await projectAvailable(settings.project)) {
    await fs.writeFile(importFile, JSON.stringify({ project: settings.project }), {flag:'wx'}).catch(error=>{if(error.code!=='EEXIST') throw error;});
  }
  const child = spawn(process.execPath, [path.join(__dirname,'server-bootstrap.cjs'),runtime,data], {
    cwd:runtime, windowsHide:true, stdio:'ignore',
    env:{...process.env,ELECTRON_RUN_AS_NODE:'1',NODE_ENV:'production'}
  });
  ownedServer=child;
  child.once('error',()=>{ if(ownedServer===child) ownedServer=null; status('Hylix could not start. Choose Retry to open it again.'); });
  child.once('exit',()=>{
    if(ownedServer===child) ownedServer=null;
    if(!closing) showLauncher('Hylix stopped unexpectedly. Choose Retry to reopen your cinema.');
  });
  return true;
}
function showCinema() {
  if (cinema && !cinema.isDestroyed()) {
    if (!cinemaLoaded) {
      void cinema.loadURL(settings.address).catch(() => showLauncher('Hylix could not open. Try again.'));
      return;
    }
    showReadyWindow(cinema);
    return;
  }
  cinema = new BrowserWindow({
    title: "Hylix",
    width: 1440,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    backgroundColor: "#08090b",
    show: false,
    icon,
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      partition: "persist:hylix",
    },
  });
  cinema.once("ready-to-show", () => {
    cinemaLoaded = true;
    status("Hylix is ready.");
    cinema.maximize();
    cinema.show();
    launcher.hide();
  });
  keepReadyOnClose(cinema, () => !closing && !!tray);
  cinema.on("closed", () => {
    cinema = null;
    cinemaLoaded = false;
    if (!closing) app.quit();
  });
  const guard = (event, url) => {
    if (sameSite(url, settings.address)) return;
    event.preventDefault();
    // Provider login needs a native handoff before desktop accounts can share sessions.
    if (externalAddress(url))
      showLauncher(
        "This link opens outside Hylix. Use “Open in browser” for browser sign-in.",
      );
  };
  cinema.webContents.on("will-navigate", guard);
  cinema.webContents.on("will-redirect", guard);
  cinema.webContents.setWindowOpenHandler(({ url }) => {
    if (sameSite(url, settings.address))
      cinema
        .loadURL(url)
        .catch(() => showLauncher("The page could not open. Try again."));
    else if (externalAddress(url))
      showLauncher("Use “Open in browser” to follow links outside Hylix.");
    return { action: "deny" };
  });
  cinema.webContents.on(
    "did-fail-load",
    (_event, code, _description, _url, isMainFrame) => {
      if (isMainFrame && code !== -3)
        cinemaLoaded = false;
      if (isMainFrame && code !== -3)
        showLauncher(
          "Hylix is unavailable. Check the connection and try again.",
        );
    },
  );
  cinema.webContents.on("render-process-gone", () =>
    showLauncher("The Hylix window stopped. Reload it from the View menu."),
  );
  cinema
    .loadURL(settings.address)
    .catch(() =>
      showLauncher("Hylix could not open. Try the connection again."),
    );
}
async function connect() {
  if (connecting) return;
  connecting = true;
  status("Opening your cinema…", true);
  try {
    // Online clients load immediately without starting a local server.
    if (!localDevelopment(settings.address)) {
      showCinema();
      return;
    }
    if (await localHealth(settings.address)) {
      showCinema();
      return;
    }
    if (!(await startLocalServer())) {
      status(
        "Hylix could not connect. Retry, or check your connection in Advanced settings.",
      );
      return;
    }
    status("Opening your library…", true);
    const deadline = Date.now() + 120000;
    while (!closing && Date.now() < deadline) {
      if (await localHealth(settings.address)) {
        showCinema();
        return;
      }
      if (!ownedServer || ownedServer.exitCode !== null) break;
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    status(
      "Hylix could not finish starting. Choose Retry. If another app uses port 3000, close it first.",
    );
  } finally {
    connecting = false;
    status(lastMessage, !!cinema && !cinema.isVisible());
  }
}
function trustedSender(event) {
  return event.senderFrame?.url === uiUrl;
}
function handle(channel, handler) {
  ipcMain.handle(channel, async (event, ...args) => {
    if (!trustedSender(event))
      throw new Error("Unavailable outside the Hylix connection screen.");
    try {
      return { ok: true, ...(await handler(...args)) };
    } catch (error) {
      return { ok: false, message: error.message || "Try again." };
    }
  });
}
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on("second-instance", () => {
    const win = cinema || launcher;
    if (win === cinema && !cinemaLoaded) showLauncher();
    else showReadyWindow(win);
  });
  app
    .whenReady()
    .then(async () => {
      if (process.platform !== "win32") {
        dialog.showErrorBox(
          "Hylix for Windows",
          "This project targets Windows 10 and 11.",
        );
        app.quit();
        return;
      }
      app.setAppUserModelId("com.hylix.desktop");
      try {
        tray = new Tray(icon);
        tray.setToolTip('Hylix · ready to reopen');
        const open = () => {
          if (!cinemaLoaded || !showReadyWindow(cinema)) showLauncher();
        };
        tray.setContextMenu(Menu.buildFromTemplate([
          { label: 'Open Hylix', click: open },
          { type: 'separator' },
          { label: 'Quit Hylix', click: () => app.quit() },
        ]));
        tray.on('click', open);
      } catch {
        // If the tray is unavailable, closing still exits normally.
        tray = null;
      }
      try {
        if (online) throw Error('The online edition uses its release service');
        const saved = JSON.parse(await fs.readFile(settingsFile(), "utf8"));
        settings.address = siteAddress(saved.address);
        settings.project =
          typeof saved.project === "string" ? saved.project : "";
      } catch {
        /* Fresh installs and online releases keep their distribution defaults. */
      }
      const sibling = path.resolve(__dirname, "../../hylix");
      if (!online && !settings.project && (await projectAvailable(sibling)))
        settings.project = sibling;
      const viewerSession = session.fromPartition("persist:hylix");
      viewerSession.setPermissionRequestHandler(
        (contents, permission, callback) =>
          callback(
            permission === "fullscreen" &&
              sameSite(contents.getURL(), settings.address),
          ),
      );
      viewerSession.setPermissionCheckHandler(
        (contents, permission) =>
          permission === "fullscreen" &&
          !!contents &&
          sameSite(contents.getURL(), settings.address),
      );
      launcher = new BrowserWindow({
        title: "Hylix",
        width: 600,
        height: 650,
        minWidth: 500,
        minHeight: 600,
        autoHideMenuBar: true,
        backgroundColor: "#08090b",
        icon,
        webPreferences: {
          preload: path.join(__dirname, "preload.cjs"),
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: true,
          webSecurity: true,
        },
      });
      launcher.on("close", (event) => {
        if (cinema && !cinema.isDestroyed() && !closing) {
          event.preventDefault();
          launcher.hide();
        }
      });
      launcher.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
      launcher.webContents.on("will-navigate", (event, url) => {
        if (url !== uiUrl) event.preventDefault();
      });
      handle("hylix:settings", async () => ({
        address: settings.address,
        projectSelected: !!settings.project,
        online,
      }));
      handle("hylix:connect", async (address) => {
        const normalized = online ? distribution.origin : siteAddress(address);
        if (cinema && normalized !== settings.address) {
          const old = cinema;
          cinema = null;
          old.removeAllListeners("closed");
          old.close();
        }
        settings.address = normalized;
        await saveSettings();
        void connect().catch(() =>
          status("The connection could not complete. Try again."),
        );
        return {};
      });
      handle("hylix:choose-project", async () => {
        if (online) throw Error('The online edition uses your shared Hylix library.');
        const picked = await dialog.showOpenDialog(launcher, {
          title: "Choose the Hylix website project",
          properties: ["openDirectory"],
        });
        if (picked.canceled || !picked.filePaths[0]) return {};
        if (!(await projectAvailable(picked.filePaths[0])))
          throw new Error(
            "Choose the Hylix folder containing package.json, .env, and installed dependencies.",
          );
        settings.project = picked.filePaths[0];
        await saveSettings();
        return { projectSelected: true };
      });
      handle("hylix:browser", async () => {
        await shell.openExternal(settings.address);
        return {};
      });
      Menu.setApplicationMenu(
        Menu.buildFromTemplate([
          {
            label: "Hylix",
            submenu: [
              {
                label: "Home",
                click: () => {
                  cinema
                    ?.loadURL(settings.address)
                    .catch(() =>
                      showLauncher("Hylix could not open. Try again."),
                    );
                },
              },
              { label: "Connection settings", click: () => showLauncher() },
              ...(online ? [{label: 'Check for updates', click: () => {
                void updates().catch(() => status('Updates are unavailable. Try again later.'));
              }}] : []),
              {
                label: "Open in browser",
                click: () => {
                  shell
                    .openExternal(settings.address)
                    .catch(() => status("Your browser could not open."));
                },
              },
              { type: "separator" },
              { role: "quit" },
            ],
          },
          {
            label: "View",
            submenu: [
              { role: "reload" },
              { role: "forceReload" },
              { role: "resetZoom" },
              { role: "zoomIn" },
              { role: "zoomOut" },
              { role: "togglefullscreen" },
            ],
          },
        ]),
      );
      await launcher.loadFile(uiFile);
      // The production runtime is included; private data stays in userData.
      void connect().catch(() => showLauncher("Hylix could not start. Choose Retry to try again."));
    })
    .catch(() => {
      dialog.showErrorBox(
        "Hylix",
        "The desktop client could not start. Please relaunch it.",
      );
      app.quit();
    });
  app.on("before-quit", () => {
    closing = true;
    if (ownedServer?.pid && ownedServer.exitCode === null) {
      spawn("taskkill.exe", ["/PID", String(ownedServer.pid), "/T", "/F"], {
        windowsHide: true,
        stdio: "ignore",
      });
      ownedServer = null;
    }
  });
  app.on("window-all-closed", () => app.quit());
}
