'use strict';

function showReadyWindow(window) {
  if (!window || window.isDestroyed()) return false;
  if (window.isMinimized()) window.restore();
  window.webContents.setAudioMuted(false);
  window.show();
  window.focus();
  return true;
}

function keepReadyOnClose(window, shouldKeepReady) {
  window.on('close', event => {
    if (!shouldKeepReady()) return;
    event.preventDefault();
    window.webContents.setAudioMuted(true);
    // Pause local players; keep the loaded catalog and profile session ready.
    void window.webContents.executeJavaScript(
      "document.querySelectorAll('video,audio').forEach(media => media.pause())",
    ).catch(() => {});
    window.hide();
  });
}
module.exports = { showReadyWindow, keepReadyOnClose };
