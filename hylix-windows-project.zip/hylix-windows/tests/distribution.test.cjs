'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { desktopConfiguration } = require('../src/distribution.cjs');
test('keeps the owner edition local unless an online release is explicitly configured',()=>{
  assert.deepEqual(desktopConfiguration(),{mode:'local',origin:'http://127.0.0.1:3000/'});
});
test('public builds pin a real HTTPS service and a GitHub release repository',()=>{
  const actual=desktopConfiguration({mode:'online',origin:'https://hylix.zyru.workers.dev',repository:'hylix/hylix-desktop'});
  assert.equal(actual.origin,'https://hylix.zyru.workers.dev/');
  assert.equal(actual.releases,'https://github.com/hylix/hylix-desktop/releases/latest');
});
test('refuses localhost, placeholder domains, paths and unconfigured releases',()=>{
  for(const origin of ['http://127.0.0.1:3000','https://127.0.0.1','https://[::1]','https://localhost','https://hylix.local','https://example.com','https://hylix.invalid','https://hylix.com/admin'])
    assert.throws(()=>desktopConfiguration({mode:'online',origin,repository:'hylix/desktop'}));
  assert.throws(()=>desktopConfiguration({mode:'online',origin:'https://hylix.workers.dev'}));
  assert.throws(()=>desktopConfiguration({mode:'online',origin:'https://hylix.workers.dev',repository:'../../escape'}));
});
