'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { localHealth } = require('../src/health.cjs');

test('readiness probes the small uncached endpoint instead of the catalog homepage', async () => {
  assert.equal(await localHealth('http://127.0.0.1:3000/', async (url, options) => {
    assert.equal(String(url), 'http://127.0.0.1:3000/api/health');
    assert.equal(options.redirect, 'error');
    assert.equal(options.cache, 'no-store');
    return Response.json({ service: 'hylix', ready: true, protocol: 1 });
  }), true);
});
test('does not mistake a different app, error or unsupported protocol for Hylix', async () => {
  for (const response of [
    new Response('<title>Hylix</title>', { headers: {'content-type': 'text/html'} }),
    Response.json({service:'another-app',ready:true,protocol:1}),
    Response.json({service:'hylix',ready:false,protocol:1}, {status:503}),
    Response.json({service:'hylix',ready:true,protocol:2}),
    new Response('{broken', {headers:{'content-type':'application/json'}}),
  ]) assert.equal(await localHealth('http://127.0.0.1:3000/', async()=>response), false);
  assert.equal(await localHealth('http://127.0.0.1:3000/', async()=>{throw Error('offline');}), false);
});
