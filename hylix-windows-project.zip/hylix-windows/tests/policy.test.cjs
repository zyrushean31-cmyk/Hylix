"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const {
  siteAddress,
  sameSite,
  externalAddress,
  localDevelopment,
} = require("../src/policy.cjs");
test("accepts a hosted HTTPS site or local Hylix server", () => {
  assert.equal(
    siteAddress(" https://hylix.example/ "),
    "https://hylix.example/",
  );
  assert.equal(siteAddress("http://127.0.0.1:3000"), "http://127.0.0.1:3000/");
  assert.equal(siteAddress("http://localhost:3000/"), "http://localhost:3000/");
});
test("rejects unsafe schemes, credentials and misleading website paths", () => {
  for (const value of [
    "file:///C:/secret",
    "javascript:alert(1)",
    "data:text/html,test",
    "http://example.com",
    "https://user:pass@example.com",
    "https://example.com/admin",
    "https://example.com/?token=secret",
    "https://example.com/#other",
    null,
    3,
  ])
    assert.throws(() => siteAddress(value));
});
test("locks internal navigation to the configured origin", () => {
  const site = "http://127.0.0.1:3000/";
  assert.equal(sameSite(site + "movie/id", site), true);
  assert.equal(sameSite("http://127.0.0.1:3001/", site), false);
  assert.equal(sameSite("https://127.0.0.1:3000.evil.example/", site), false);
  assert.equal(sameSite("file:///C:/secret", site), false);
});
test("external links use HTTPS and never native shell schemes", () => {
  assert.equal(
    externalAddress("https://www.youtube.com/watch?v=example"),
    true,
  );
  for (const url of [
    "file:///C:/Windows",
    "powershell:command",
    "ms-settings:",
    "https://user:pass@example.com",
  ])
    assert.equal(externalAddress(url), false);
});
test("automatic source server startup is restricted to the local development origin", () => {
  assert.equal(localDevelopment("http://127.0.0.1:3000/"), true);
  assert.equal(localDevelopment("https://hylix.example/"), false);
  assert.equal(localDevelopment("http://localhost:3001/"), false);
});
