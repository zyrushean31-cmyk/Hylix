'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {showReadyWindow,keepReadyOnClose}=require('../src/quick-reopen.cjs');
function fixture(){const window=new EventEmitter();const calls=[];Object.assign(window,{isDestroyed:()=>false,isMinimized:()=>true,restore:()=>calls.push('restore'),show:()=>calls.push('show'),hide:()=>calls.push('hide'),focus:()=>calls.push('focus'),webContents:{setAudioMuted:muted=>calls.push(['mute',muted]),executeJavaScript:async()=>{calls.push('pause-media');},loadURL:()=>{throw Error('Quick reopen must never reload the catalog');}}});return {window,calls};}
test('reopens the same loaded window without navigation or session changes',()=>{const {window,calls}=fixture();assert.equal(showReadyWindow(window),true);assert.deepEqual(calls,['restore',['mute',false],'show','focus']);});
test('closing keeps the loaded catalog ready and silences playback',()=>{const {window,calls}=fixture();keepReadyOnClose(window,()=>true);let prevented=false;window.emit('close',{preventDefault:()=>{prevented=true;}});assert.equal(prevented,true);assert.deepEqual(calls,[['mute',true],'pause-media','hide']);});
test('explicit quit or unavailable tray permits normal shutdown',()=>{const {window,calls}=fixture();keepReadyOnClose(window,()=>false);window.emit('close',{preventDefault:()=>{throw Error('Quit must not be intercepted');}});assert.deepEqual(calls,[]);assert.equal(showReadyWindow(null),false);});
