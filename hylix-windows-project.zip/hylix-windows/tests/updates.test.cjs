'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {updateController}=require('../src/updates.cjs');
function fixture(responses){
  const updater=new EventEmitter();
  const calls=[];
  updater.checkForUpdates=async()=>{calls.push('check');updater.emit('update-available',{version:'1.0.0'});};
  updater.downloadUpdate=async()=>{calls.push('download');};
  updater.quitAndInstall=(...args)=>calls.push(['install',...args]);
  const check=updateController(updater,async options=>{calls.push(options.message);return {response:responses.shift()??0};});
  return {updater,calls,check};
}
test('does not automatically download or install and respects Later',async()=>{
  const {updater,calls,check}=fixture([1]);await check();
  assert.equal(updater.autoDownload,false);assert.equal(updater.autoInstallOnAppQuit,false);
  assert.equal(updater.allowDowngrade,false);assert.equal(updater.allowPrerelease,false);
  assert.ok(!calls.includes('download'));assert.equal(updater.listenerCount('update-available'),0);
});
test('restarts only after a verified download and an explicit Restart choice',async()=>{
  const {calls,check}=fixture([0,0]);await check();
  assert.ok(calls.indexOf('download')<calls.findIndex(x=>Array.isArray(x)));
  assert.deepEqual(calls.at(-1),['install',false,true]);
});
test('download failures do not install or expose the underlying server error',async()=>{
  const {updater,calls,check}=fixture([0]);
  updater.downloadUpdate=async()=>{throw Error('private server diagnostic');};await check();
  assert.ok(!calls.some(Array.isArray));
  assert.ok(!JSON.stringify(calls).includes('private server diagnostic'));
  assert.equal(calls.at(-1),'Updates could not be checked or downloaded.');
});
test('duplicate clicks do not create simultaneous checks',async()=>{
  const {updater,calls,check}=fixture([1]);let finish;
  updater.checkForUpdates=()=>new Promise(resolve=>{finish=resolve;calls.push('check');});
  const first=check();await check();finish();await first;
  assert.equal(calls.filter(x=>x==='check').length,1);
});
